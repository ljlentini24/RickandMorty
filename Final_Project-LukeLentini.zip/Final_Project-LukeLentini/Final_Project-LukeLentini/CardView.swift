//
//  CardView.swift
//  Final_Project-LukeLentini
//
//  Created by Luke Lentini24 on 5/24/23.
//

import SwiftUI

struct CardView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CardView_Previews: PreviewProvider {
    static var previews: some View {
        CardView()
    }
}
