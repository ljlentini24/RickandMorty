//
//  Final_Project_LukeLentiniApp.swift
//  Final_Project-LukeLentini
//
//  Created by Luke Lentini24 on 5/23/23.
//

import SwiftUI

@main
struct Final_Project_LukeLentiniApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
